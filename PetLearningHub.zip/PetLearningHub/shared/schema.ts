import { pgTable, text, serial, integer, boolean, decimal, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const classes = pgTable("classes", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  imageUrl: text("image_url").notNull(),
  instructorName: text("instructor_name").notNull(),
  location: text("location").notNull(),
  address: text("address").notNull(),
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  currency: text("currency").notNull().default("USD"),
  duration: integer("duration").notNull(), // in minutes
  maxParticipants: integer("max_participants").notNull(),
  currentParticipants: integer("current_participants").notNull().default(0),
  petTypes: text("pet_types").array().notNull(), // ["dogs", "cats", "birds", "other"]
  classTypes: text("class_types").array().notNull(), // ["training", "agility", "behavior", "socialization", "first-aid"]
  nextSessionDate: timestamp("next_session_date").notNull(),
  rating: decimal("rating", { precision: 2, scale: 1 }).notNull().default("0.0"),
  reviewCount: integer("review_count").notNull().default(0),
  distanceFromUser: decimal("distance_from_user", { precision: 5, scale: 2 }), // in miles
  isActive: boolean("is_active").notNull().default(true),
});

export const bookings = pgTable("bookings", {
  id: serial("id").primaryKey(),
  classId: integer("class_id").notNull().references(() => classes.id),
  petName: text("pet_name").notNull(),
  petTypeBreed: text("pet_type_breed").notNull(),
  ownerEmail: text("owner_email").notNull(),
  ownerPhone: text("owner_phone"),
  specialNotes: text("special_notes"),
  bookingDate: timestamp("booking_date").notNull().defaultNow(),
  status: text("status").notNull().default("confirmed"), // "confirmed", "cancelled", "completed"
});

export const insertClassSchema = createInsertSchema(classes).omit({
  id: true,
  currentParticipants: true,
  rating: true,
  reviewCount: true,
  isActive: true,
});

export const insertBookingSchema = createInsertSchema(bookings).omit({
  id: true,
  bookingDate: true,
  status: true,
});

export type InsertClass = z.infer<typeof insertClassSchema>;
export type Class = typeof classes.$inferSelect;
export type InsertBooking = z.infer<typeof insertBookingSchema>;
export type Booking = typeof bookings.$inferSelect;

// Search and filter types
export const searchFiltersSchema = z.object({
  location: z.string().optional(),
  date: z.string().optional(),
  petTypes: z.array(z.string()).optional(),
  classTypes: z.array(z.string()).optional(),
  minPrice: z.number().optional(),
  maxPrice: z.number().optional(),
  maxDistance: z.number().optional(),
  availableOnly: z.boolean().optional(),
  includeWaitlist: z.boolean().optional(),
});

export type SearchFilters = z.infer<typeof searchFiltersSchema>;
