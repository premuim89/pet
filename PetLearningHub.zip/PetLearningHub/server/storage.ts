import { classes, bookings, type Class, type Booking, type InsertClass, type InsertBooking, type SearchFilters } from "@shared/schema";

export interface IStorage {
  // Classes
  getClasses(filters?: SearchFilters): Promise<Class[]>;
  getClassById(id: number): Promise<Class | undefined>;
  createClass(classData: InsertClass): Promise<Class>;
  updateClassParticipants(classId: number, participants: number): Promise<Class | undefined>;
  
  // Bookings
  createBooking(booking: InsertBooking): Promise<Booking>;
  getBookingsByClass(classId: number): Promise<Booking[]>;
  getBookingById(id: number): Promise<Booking | undefined>;
}

export class MemStorage implements IStorage {
  private classes: Map<number, Class>;
  private bookings: Map<number, Booking>;
  private currentClassId: number;
  private currentBookingId: number;

  constructor() {
    this.classes = new Map();
    this.bookings = new Map();
    this.currentClassId = 1;
    this.currentBookingId = 1;
    
    // Initialize with sample data
    this.initializeSampleData();
  }

  private initializeSampleData() {
    const sampleClasses: InsertClass[] = [
      {
        title: "Puppy Basic Training",
        description: "Perfect for puppies 8-16 weeks old. Learn basic commands, socialization, and house training.",
        imageUrl: "https://images.unsplash.com/photo-1601758228041-f3b2795255f1?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        instructorName: "Sarah Johnson",
        location: "Happy Paws Training Center",
        address: "123 Main St, Anytown, ST 12345",
        price: "45.00",
        currency: "USD",
        duration: 60,
        maxParticipants: 8,
        currentParticipants: 3,
        petTypes: ["dogs"],
        classTypes: ["training"],
        nextSessionDate: new Date(Date.now() + 3 * 60 * 60 * 1000), // 3 hours from now
        rating: "4.8",
        reviewCount: 156,
        distanceFromUser: "2.1",
      },
      {
        title: "Dog Agility Beginner",
        description: "Fun agility course for dogs of all sizes. Build confidence and strengthen your bond.",
        imageUrl: "https://images.unsplash.com/photo-1551717743-49959800b1f6?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        instructorName: "Mike Chen",
        location: "Paws & Play Agility",
        address: "456 Oak Ave, Anytown, ST 12345",
        price: "60.00",
        currency: "USD",
        duration: 90,
        maxParticipants: 6,
        currentParticipants: 4,
        petTypes: ["dogs"],
        classTypes: ["agility"],
        nextSessionDate: new Date(Date.now() + 24 * 60 * 60 * 1000), // tomorrow
        rating: "4.9",
        reviewCount: 89,
        distanceFromUser: "0.8",
      },
      {
        title: "Cat Behavior Workshop",
        description: "Understanding your cat's behavior, solving common issues, and enrichment activities.",
        imageUrl: "https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        instructorName: "Dr. Lisa Wong",
        location: "Whiskers Wellness Center",
        address: "789 Pine St, Anytown, ST 12345",
        price: "40.00",
        currency: "USD",
        duration: 120,
        maxParticipants: 12,
        currentParticipants: 7,
        petTypes: ["cats"],
        classTypes: ["behavior"],
        nextSessionDate: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000), // 5 days from now
        rating: "4.7",
        reviewCount: 73,
        distanceFromUser: "1.5",
      },
      {
        title: "Senior Dog Care",
        description: "Special care techniques for older dogs, health monitoring, and comfort strategies.",
        imageUrl: "https://images.unsplash.com/photo-1587300003388-59208cc962cb?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        instructorName: "Jennifer Martinez",
        location: "Golden Years Pet Care",
        address: "321 Elm St, Anytown, ST 12345",
        price: "55.00",
        currency: "USD",
        duration: 75,
        maxParticipants: 10,
        currentParticipants: 10,
        petTypes: ["dogs"],
        classTypes: ["behavior"],
        nextSessionDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000),
        rating: "4.9",
        reviewCount: 124,
        distanceFromUser: "3.2",
      },
      {
        title: "Pet First Aid Training",
        description: "Essential first aid skills every pet owner should know. CPR, wound care, and emergency response.",
        imageUrl: "https://images.unsplash.com/photo-1551698618-1dfe5d97d256?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        instructorName: "Dr. Robert Kim",
        location: "Safe Paws Training",
        address: "654 Maple Dr, Anytown, ST 12345",
        price: "75.00",
        currency: "USD",
        duration: 180,
        maxParticipants: 15,
        currentParticipants: 8,
        petTypes: ["dogs", "cats"],
        classTypes: ["first-aid"],
        nextSessionDate: new Date(Date.now() + 6 * 24 * 60 * 60 * 1000),
        rating: "5.0",
        reviewCount: 45,
        distanceFromUser: "2.8",
      },
      {
        title: "Dog Socialization Group",
        description: "Supervised play sessions for dogs to socialize and exercise in a safe environment.",
        imageUrl: "https://images.unsplash.com/photo-1544568100-847a948585b9?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        instructorName: "Amanda Davis",
        location: "Social Paws Park",
        address: "987 Cedar Ln, Anytown, ST 12345",
        price: "25.00",
        currency: "USD",
        duration: 45,
        maxParticipants: 12,
        currentParticipants: 5,
        petTypes: ["dogs"],
        classTypes: ["socialization"],
        nextSessionDate: new Date(Date.now() + 2 * 60 * 60 * 1000), // 2 hours from now
        rating: "4.6",
        reviewCount: 203,
        distanceFromUser: "1.2",
      },
    ];

    sampleClasses.forEach(classData => {
      const id = this.currentClassId++;
      const fullClass: Class = {
        ...classData,
        id,
        currentParticipants: classData.currentParticipants || 0,
        rating: classData.rating || "0.0",
        reviewCount: classData.reviewCount || 0,
        isActive: true,
      };
      this.classes.set(id, fullClass);
    });
  }

  async getClasses(filters?: SearchFilters): Promise<Class[]> {
    let results = Array.from(this.classes.values()).filter(c => c.isActive);
    
    if (filters) {
      if (filters.petTypes && filters.petTypes.length > 0) {
        results = results.filter(c => 
          c.petTypes.some(type => filters.petTypes!.includes(type))
        );
      }
      
      if (filters.classTypes && filters.classTypes.length > 0) {
        results = results.filter(c => 
          c.classTypes.some(type => filters.classTypes!.includes(type))
        );
      }
      
      if (filters.minPrice !== undefined) {
        results = results.filter(c => parseFloat(c.price) >= filters.minPrice!);
      }
      
      if (filters.maxPrice !== undefined) {
        results = results.filter(c => parseFloat(c.price) <= filters.maxPrice!);
      }
      
      if (filters.maxDistance !== undefined && filters.maxDistance > 0) {
        results = results.filter(c => 
          !c.distanceFromUser || parseFloat(c.distanceFromUser) <= filters.maxDistance!
        );
      }
      
      if (filters.availableOnly) {
        results = results.filter(c => c.currentParticipants < c.maxParticipants);
      }
      
      if (filters.date) {
        const filterDate = new Date(filters.date);
        results = results.filter(c => {
          const classDate = new Date(c.nextSessionDate);
          return classDate.toDateString() === filterDate.toDateString();
        });
      }
      
      if (filters.location) {
        const searchTerm = filters.location.toLowerCase();
        results = results.filter(c => 
          c.location.toLowerCase().includes(searchTerm) ||
          c.address.toLowerCase().includes(searchTerm)
        );
      }
    }
    
    // Sort by distance, then availability, then rating
    results.sort((a, b) => {
      const aDistance = parseFloat(a.distanceFromUser || "999");
      const bDistance = parseFloat(b.distanceFromUser || "999");
      if (aDistance !== bDistance) return aDistance - bDistance;
      
      const aAvailable = a.maxParticipants - a.currentParticipants;
      const bAvailable = b.maxParticipants - b.currentParticipants;
      if (aAvailable !== bAvailable) return bAvailable - aAvailable;
      
      return parseFloat(b.rating) - parseFloat(a.rating);
    });
    
    return results;
  }

  async getClassById(id: number): Promise<Class | undefined> {
    return this.classes.get(id);
  }

  async createClass(classData: InsertClass): Promise<Class> {
    const id = this.currentClassId++;
    const newClass: Class = {
      ...classData,
      id,
      currentParticipants: 0,
      rating: "0.0",
      reviewCount: 0,
      isActive: true,
    };
    this.classes.set(id, newClass);
    return newClass;
  }

  async updateClassParticipants(classId: number, participants: number): Promise<Class | undefined> {
    const existingClass = this.classes.get(classId);
    if (existingClass) {
      const updatedClass = { ...existingClass, currentParticipants: participants };
      this.classes.set(classId, updatedClass);
      return updatedClass;
    }
    return undefined;
  }

  async createBooking(booking: InsertBooking): Promise<Booking> {
    const id = this.currentBookingId++;
    const newBooking: Booking = {
      ...booking,
      id,
      bookingDate: new Date(),
      status: "confirmed",
    };
    this.bookings.set(id, newBooking);
    
    // Update class participant count
    const existingClass = this.classes.get(booking.classId);
    if (existingClass) {
      await this.updateClassParticipants(
        booking.classId, 
        existingClass.currentParticipants + 1
      );
    }
    
    return newBooking;
  }

  async getBookingsByClass(classId: number): Promise<Booking[]> {
    return Array.from(this.bookings.values()).filter(b => b.classId === classId);
  }

  async getBookingById(id: number): Promise<Booking | undefined> {
    return this.bookings.get(id);
  }
}

export const storage = new MemStorage();
