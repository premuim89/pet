const CACHE_NAME = 'pawclass-v1';
const OFFLINE_CACHE_KEY = 'pawclass-offline-data';

export class OfflineManager {
  static async cacheData(key: string, data: any): Promise<void> {
    try {
      const cachedData = this.getCachedData();
      cachedData[key] = {
        data,
        timestamp: Date.now()
      };
      localStorage.setItem(OFFLINE_CACHE_KEY, JSON.stringify(cachedData));
    } catch (error) {
      console.warn('Failed to cache data:', error);
    }
  }

  static getCachedData(): Record<string, { data: any; timestamp: number }> {
    try {
      const cached = localStorage.getItem(OFFLINE_CACHE_KEY);
      return cached ? JSON.parse(cached) : {};
    } catch (error) {
      console.warn('Failed to get cached data:', error);
      return {};
    }
  }

  static getOfflineData(key: string): any | null {
    const cachedData = this.getCachedData();
    const item = cachedData[key];
    
    if (!item) return null;
    
    // Check if data is older than 24 hours
    const isExpired = Date.now() - item.timestamp > 24 * 60 * 60 * 1000;
    if (isExpired) {
      this.clearCachedData(key);
      return null;
    }
    
    return item.data;
  }

  static clearCachedData(key?: string): void {
    try {
      if (key) {
        const cachedData = this.getCachedData();
        delete cachedData[key];
        localStorage.setItem(OFFLINE_CACHE_KEY, JSON.stringify(cachedData));
      } else {
        localStorage.removeItem(OFFLINE_CACHE_KEY);
      }
    } catch (error) {
      console.warn('Failed to clear cached data:', error);
    }
  }

  static async preloadCriticalData(): Promise<void> {
    if (!navigator.onLine) return;

    try {
      // Cache popular classes for offline viewing
      const response = await fetch('/api/classes?availableOnly=true');
      if (response.ok) {
        const classes = await response.json();
        this.cacheData('classes', classes);
      }
    } catch (error) {
      console.warn('Failed to preload critical data:', error);
    }
  }
}

// Initialize offline manager
if (typeof window !== 'undefined') {
  OfflineManager.preloadCriticalData();
  
  // Preload data when coming back online
  window.addEventListener('online', () => {
    OfflineManager.preloadCriticalData();
  });
}
