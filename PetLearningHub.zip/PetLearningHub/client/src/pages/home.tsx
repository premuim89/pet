import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Header } from "@/components/header";
import { SearchFilters } from "@/components/search-filters";
import { ClassCard } from "@/components/class-card";
import { BookingModal } from "@/components/booking-modal";
import { FilterModal } from "@/components/filter-modal";
import { BottomNavigation } from "@/components/bottom-navigation";
import { Button } from "@/components/ui/button";
import { Grid, List } from "lucide-react";
import type { Class, SearchFilters as SearchFiltersType } from "@shared/schema";

export default function Home() {
  const [selectedClass, setSelectedClass] = useState<Class | null>(null);
  const [showBookingModal, setShowBookingModal] = useState(false);
  const [showFilterModal, setShowFilterModal] = useState(false);
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [searchFilters, setSearchFilters] = useState<SearchFiltersType>({
    availableOnly: true,
  });

  const { data: classes = [], isLoading, error } = useQuery({
    queryKey: ["/api/classes", searchFilters],
    queryFn: async () => {
      const params = new URLSearchParams();
      
      Object.entries(searchFilters).forEach(([key, value]) => {
        if (value !== undefined && value !== null && value !== "") {
          if (Array.isArray(value)) {
            value.forEach(v => params.append(`${key}[]`, v.toString()));
          } else {
            params.append(key, value.toString());
          }
        }
      });
      
      const response = await fetch(`/api/classes?${params.toString()}`);
      if (!response.ok) {
        throw new Error(`Failed to fetch classes: ${response.statusText}`);
      }
      return response.json();
    },
  });

  const handleClassSelect = (classData: Class) => {
    setSelectedClass(classData);
    setShowBookingModal(true);
  };

  const handleBookingSuccess = () => {
    setShowBookingModal(false);
    setSelectedClass(null);
  };

  const handleFiltersApply = (filters: SearchFiltersType) => {
    setSearchFilters(filters);
    setShowFilterModal(false);
  };

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Unable to load classes</h2>
            <p className="text-gray-600">Please check your connection and try again.</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-16 md:pb-0">
      <Header />
      
      <SearchFilters 
        filters={searchFilters}
        onFiltersChange={setSearchFilters}
        onShowFilterModal={() => setShowFilterModal(true)}
      />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Results Header */}
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold text-gray-900">
            {isLoading ? (
              <span>Loading classes...</span>
            ) : (
              <span>{classes.length} classes available near you</span>
            )}
          </h1>
          <div className="flex items-center space-x-2">
            <Button
              variant={viewMode === "grid" ? "default" : "outline"}
              size="sm"
              onClick={() => setViewMode("grid")}
              className="p-2"
            >
              <Grid className="h-4 w-4" />
            </Button>
            <Button
              variant={viewMode === "list" ? "default" : "outline"}
              size="sm"
              onClick={() => setViewMode("list")}
              className="p-2"
            >
              <List className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Classes Grid/List */}
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="bg-white rounded-xl shadow-sm p-4 animate-pulse">
                <div className="w-full h-48 bg-gray-200 rounded-lg mb-4"></div>
                <div className="space-y-2">
                  <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                  <div className="h-3 bg-gray-200 rounded w-full"></div>
                  <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                </div>
              </div>
            ))}
          </div>
        ) : classes.length === 0 ? (
          <div className="text-center py-12">
            <h3 className="text-lg font-medium text-gray-900 mb-2">No classes found</h3>
            <p className="text-gray-600">Try adjusting your filters or search location.</p>
          </div>
        ) : (
          <div className={viewMode === "grid" 
            ? "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" 
            : "space-y-4"
          }>
            {classes.map((classData) => (
              <ClassCard
                key={classData.id}
                classData={classData}
                viewMode={viewMode}
                onSelect={handleClassSelect}
              />
            ))}
          </div>
        )}

        {/* Load More Button - placeholder for future pagination */}
        {classes.length > 0 && (
          <div className="text-center mt-8">
            <Button variant="outline" disabled>
              Load More Classes
            </Button>
          </div>
        )}
      </main>

      <BottomNavigation />

      {/* Modals */}
      {showBookingModal && selectedClass && (
        <BookingModal
          classData={selectedClass}
          onClose={() => setShowBookingModal(false)}
          onSuccess={handleBookingSuccess}
        />
      )}

      {showFilterModal && (
        <FilterModal
          filters={searchFilters}
          onClose={() => setShowFilterModal(false)}
          onApply={handleFiltersApply}
        />
      )}
    </div>
  );
}
