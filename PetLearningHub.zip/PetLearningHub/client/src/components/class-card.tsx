import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { MapPin, Clock, Star } from "lucide-react";
import type { Class } from "@shared/schema";

interface ClassCardProps {
  classData: Class;
  viewMode: "grid" | "list";
  onSelect: (classData: Class) => void;
}

export function ClassCard({ classData, viewMode, onSelect }: ClassCardProps) {
  const isAvailable = classData.currentParticipants < classData.maxParticipants;
  const spotsLeft = classData.maxParticipants - classData.currentParticipants;
  
  const getAvailabilityBadge = () => {
    if (spotsLeft === 0) {
      return <Badge variant="destructive">Full</Badge>;
    } else if (spotsLeft <= 2) {
      return <Badge className="bg-warning text-white">{spotsLeft} spots left</Badge>;
    } else {
      return <Badge className="bg-success text-white">Available</Badge>;
    }
  };

  const formatNextSession = () => {
    const date = new Date(classData.nextSessionDate);
    const now = new Date();
    const isToday = date.toDateString() === now.toDateString();
    const isTomorrow = date.toDateString() === new Date(now.getTime() + 86400000).toDateString();
    
    if (isToday) {
      return `Today ${date.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}`;
    } else if (isTomorrow) {
      return `Tomorrow ${date.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}`;
    } else {
      return date.toLocaleDateString([], { 
        weekday: 'long', 
        hour: 'numeric', 
        minute: '2-digit' 
      });
    }
  };

  if (viewMode === "list") {
    return (
      <Card className="cursor-pointer hover:shadow-md transition-shadow">
        <CardContent className="p-4">
          <div className="flex gap-4">
            <img
              src={classData.imageUrl}
              alt={classData.title}
              className="w-24 h-24 object-cover rounded-lg flex-shrink-0"
            />
            <div className="flex-1 min-w-0">
              <div className="flex items-start justify-between mb-2">
                <div>
                  <h3 className="font-semibold text-lg text-gray-900 truncate">
                    {classData.title}
                  </h3>
                  <p className="text-sm text-gray-600 line-clamp-2">
                    {classData.description}
                  </p>
                </div>
                <div className="flex flex-col items-end gap-2 ml-4">
                  {getAvailabilityBadge()}
                  <span className="text-sm text-gray-500">
                    {classData.distanceFromUser} mi away
                  </span>
                </div>
              </div>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center text-sm text-gray-500">
                  <MapPin className="h-4 w-4 mr-1" />
                  <span className="truncate">{classData.location}</span>
                </div>
                <div className="flex items-center gap-4">
                  <div className="flex items-center text-yellow-500">
                    <Star className="h-4 w-4 fill-current" />
                    <span className="ml-1 text-sm text-gray-600">
                      {classData.rating} ({classData.reviewCount})
                    </span>
                  </div>
                  <div className="text-right">
                    <span className="text-lg font-bold text-primary">
                      ${classData.price}
                    </span>
                    <span className="text-gray-500 text-sm">/class</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="mt-3 flex items-center justify-between">
            <div className="flex items-center text-sm text-gray-500">
              <Clock className="h-4 w-4 mr-1" />
              Next: {formatNextSession()}
            </div>
            <Button onClick={() => onSelect(classData)} size="sm">
              Book Now
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => onSelect(classData)}>
      <img
        src={classData.imageUrl}
        alt={classData.title}
        className="w-full h-48 object-cover rounded-t-xl"
      />
      
      <CardContent className="p-5">
        <div className="flex items-center justify-between mb-2">
          {getAvailabilityBadge()}
          <span className="text-gray-500 text-sm">
            {classData.distanceFromUser} mi away
          </span>
        </div>
        
        <h3 className="font-semibold text-lg text-gray-900 mb-2">
          {classData.title}
        </h3>
        <p className="text-gray-600 text-sm mb-3">
          {classData.description}
        </p>
        
        <div className="flex items-center text-sm text-gray-500 mb-3">
          <MapPin className="h-4 w-4 mr-1" />
          <span>{classData.location}</span>
        </div>
        
        <div className="flex items-center justify-between">
          <div>
            <span className="text-lg font-bold text-primary">
              ${classData.price}
            </span>
            <span className="text-gray-500 text-sm">/class</span>
          </div>
          
          <div className="flex items-center text-yellow-500">
            <Star className="h-4 w-4 fill-current" />
            <span className="ml-1 text-sm text-gray-600">
              {classData.rating} ({classData.reviewCount})
            </span>
          </div>
        </div>
        
        <div className="mt-3 text-sm text-gray-500">
          <Clock className="h-4 w-4 inline mr-1" />
          Next: {formatNextSession()}
        </div>
      </CardContent>
    </Card>
  );
}
