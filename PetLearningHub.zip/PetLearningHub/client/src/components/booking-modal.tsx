import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Calendar, Clock, MapPin } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type { Class } from "@shared/schema";

const bookingFormSchema = z.object({
  petName: z.string().min(1, "Pet name is required"),
  petTypeBreed: z.string().min(1, "Pet type and breed is required"),
  ownerEmail: z.string().email("Valid email is required"),
  ownerPhone: z.string().optional(),
  specialNotes: z.string().optional(),
});

type BookingFormData = z.infer<typeof bookingFormSchema>;

interface BookingModalProps {
  classData: Class;
  onClose: () => void;
  onSuccess: () => void;
}

export function BookingModal({ classData, onClose, onSuccess }: BookingModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const form = useForm<BookingFormData>({
    resolver: zodResolver(bookingFormSchema),
    defaultValues: {
      petName: "",
      petTypeBreed: "",
      ownerEmail: "",
      ownerPhone: "",
      specialNotes: "",
    },
  });

  const bookingMutation = useMutation({
    mutationFn: async (data: BookingFormData) => {
      const response = await apiRequest("POST", "/api/bookings", {
        classId: classData.id,
        ...data,
      });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Booking Confirmed!",
        description: "Your class has been successfully booked.",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/classes"] });
      onSuccess();
    },
    onError: (error: Error) => {
      toast({
        title: "Booking Failed",
        description: error.message || "Unable to book the class. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: BookingFormData) => {
    bookingMutation.mutate(data);
  };

  const formatDateTime = () => {
    const date = new Date(classData.nextSessionDate);
    const now = new Date();
    const isToday = date.toDateString() === now.toDateString();
    const isTomorrow = date.toDateString() === new Date(now.getTime() + 86400000).toDateString();
    
    if (isToday) {
      return `Today ${date.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}`;
    } else if (isTomorrow) {
      return `Tomorrow ${date.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}`;
    } else {
      return date.toLocaleDateString([], { 
        weekday: 'long',
        month: 'short',
        day: 'numeric',
        hour: 'numeric', 
        minute: '2-digit' 
      });
    }
  };

  const isFullyBooked = classData.currentParticipants >= classData.maxParticipants;

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-md max-h-screen overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Book Class</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          <div>
            <img
              src={classData.imageUrl}
              alt={classData.title}
              className="w-full h-32 object-cover rounded-lg"
            />
            
            <div className="mt-4">
              <h4 className="font-semibold text-lg mb-2">{classData.title}</h4>
              <p className="text-gray-600 text-sm mb-4">{classData.description}</p>
              
              <div className="border-t border-b py-4 space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Date & Time</span>
                  <span className="font-medium">{formatDateTime()}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Duration</span>
                  <span className="font-medium">{classData.duration} minutes</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Location</span>
                  <span className="font-medium text-right">{classData.location}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Price</span>
                  <span className="font-bold text-primary text-lg">${classData.price}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Availability</span>
                  <div>
                    {isFullyBooked ? (
                      <Badge variant="destructive">Fully Booked</Badge>
                    ) : (
                      <Badge className="bg-success text-white">
                        {classData.maxParticipants - classData.currentParticipants} spots left
                      </Badge>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {isFullyBooked ? (
            <div className="text-center py-4">
              <p className="text-gray-600 mb-4">This class is currently full.</p>
              <Button variant="outline" onClick={onClose} className="w-full">
                Close
              </Button>
            </div>
          ) : (
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="petName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Pet Name *</FormLabel>
                      <FormControl>
                        <Input placeholder="Enter your pet's name" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="petTypeBreed"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Pet Type & Breed *</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g., Dog - Golden Retriever" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="ownerEmail"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email Address *</FormLabel>
                      <FormControl>
                        <Input type="email" placeholder="your@email.com" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="ownerPhone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Phone Number (Optional)</FormLabel>
                      <FormControl>
                        <Input type="tel" placeholder="(555) 123-4567" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="specialNotes"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Special Notes (Optional)</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Any special requirements or notes..."
                          rows={3}
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="flex gap-3 pt-4">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={onClose}
                    className="flex-1"
                    disabled={bookingMutation.isPending}
                  >
                    Cancel
                  </Button>
                  <Button
                    type="submit"
                    className="flex-1 bg-primary text-white hover:bg-primary/90"
                    disabled={bookingMutation.isPending}
                  >
                    {bookingMutation.isPending ? "Booking..." : "Book Now"}
                  </Button>
                </div>
              </form>
            </Form>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
