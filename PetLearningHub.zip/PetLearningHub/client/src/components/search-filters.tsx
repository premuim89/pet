import { useState } from "react";
import { MapPin, Calendar, Filter } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import type { SearchFilters } from "@shared/schema";

interface SearchFiltersProps {
  filters: SearchFilters;
  onFiltersChange: (filters: SearchFilters) => void;
  onShowFilterModal: () => void;
}

export function SearchFilters({ filters, onFiltersChange, onShowFilterModal }: SearchFiltersProps) {
  const [location, setLocation] = useState(filters.location || "");
  const [date, setDate] = useState(filters.date || "");

  const handleLocationChange = (value: string) => {
    setLocation(value);
    onFiltersChange({ ...filters, location: value || undefined });
  };

  const handleDateChange = (value: string) => {
    setDate(value);
    onFiltersChange({ ...filters, date: value || undefined });
  };

  const quickFilters = [
    { label: "All Pets", active: !filters.petTypes?.length, onClick: () => onFiltersChange({ ...filters, petTypes: undefined }) },
    { label: "Dogs", active: filters.petTypes?.includes("dogs"), onClick: () => onFiltersChange({ ...filters, petTypes: ["dogs"] }) },
    { label: "Cats", active: filters.petTypes?.includes("cats"), onClick: () => onFiltersChange({ ...filters, petTypes: ["cats"] }) },
    { label: "Training", active: filters.classTypes?.includes("training"), onClick: () => onFiltersChange({ ...filters, classTypes: ["training"] }) },
    { label: "Agility", active: filters.classTypes?.includes("agility"), onClick: () => onFiltersChange({ ...filters, classTypes: ["agility"] }) },
    { label: "Nearby", active: filters.maxDistance === 5, onClick: () => onFiltersChange({ ...filters, maxDistance: filters.maxDistance === 5 ? undefined : 5 }) },
  ];

  return (
    <div className="bg-white shadow-sm border-b">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div className="flex flex-col sm:flex-row gap-4">
          {/* Location Search */}
          <div className="flex-1">
            <div className="relative">
              <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                type="text"
                placeholder="Enter your location"
                value={location}
                onChange={(e) => handleLocationChange(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>
          
          {/* Date Filter */}
          <div className="sm:w-48">
            <div className="relative">
              <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                type="date"
                value={date}
                onChange={(e) => handleDateChange(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>
          
          {/* Filters Button */}
          <Button 
            onClick={onShowFilterModal}
            className="bg-primary text-white hover:bg-primary/90"
          >
            <Filter className="h-4 w-4 mr-2" />
            Filters
          </Button>
        </div>
        
        {/* Quick Filters */}
        <div className="flex flex-wrap gap-2 mt-4">
          {quickFilters.map((filter) => (
            <Button
              key={filter.label}
              variant={filter.active ? "default" : "outline"}
              size="sm"
              onClick={filter.onClick}
              className={filter.active ? "bg-accent text-white hover:bg-accent/90" : ""}
            >
              {filter.label}
            </Button>
          ))}
        </div>
      </div>
    </div>
  );
}
