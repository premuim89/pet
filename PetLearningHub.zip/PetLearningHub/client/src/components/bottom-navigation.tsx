import { Search, Calendar, Heart, User } from "lucide-react";
import { Button } from "@/components/ui/button";

export function BottomNavigation() {
  const navItems = [
    { icon: Search, label: "Discover", active: true },
    { icon: Calendar, label: "My Classes", active: false },
    { icon: Heart, label: "Favorites", active: false },
    { icon: User, label: "Profile", active: false },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 md:hidden">
      <div className="flex justify-around py-2">
        {navItems.map(({ icon: Icon, label, active }) => (
          <Button
            key={label}
            variant="ghost"
            className={`flex flex-col items-center py-2 px-3 ${
              active ? "text-primary" : "text-gray-400"
            }`}
            size="sm"
          >
            <Icon className="h-5 w-5 mb-1" />
            <span className="text-xs">{label}</span>
          </Button>
        ))}
      </div>
    </nav>
  );
}
