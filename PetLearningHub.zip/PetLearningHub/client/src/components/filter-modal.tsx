import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import type { SearchFilters } from "@shared/schema";

interface FilterModalProps {
  filters: SearchFilters;
  onClose: () => void;
  onApply: (filters: SearchFilters) => void;
}

export function FilterModal({ filters, onClose, onApply }: FilterModalProps) {
  const [localFilters, setLocalFilters] = useState<SearchFilters>(filters);

  const handlePetTypeChange = (petType: string, checked: boolean) => {
    const currentTypes = localFilters.petTypes || [];
    if (checked) {
      setLocalFilters({
        ...localFilters,
        petTypes: [...currentTypes, petType]
      });
    } else {
      setLocalFilters({
        ...localFilters,
        petTypes: currentTypes.filter(type => type !== petType)
      });
    }
  };

  const handleClassTypeChange = (classType: string, checked: boolean) => {
    const currentTypes = localFilters.classTypes || [];
    if (checked) {
      setLocalFilters({
        ...localFilters,
        classTypes: [...currentTypes, classType]
      });
    } else {
      setLocalFilters({
        ...localFilters,
        classTypes: currentTypes.filter(type => type !== classType)
      });
    }
  };

  const handleApplyFilters = () => {
    onApply(localFilters);
  };

  const handleClearAll = () => {
    setLocalFilters({});
  };

  const petTypes = [
    { id: "dogs", label: "Dogs" },
    { id: "cats", label: "Cats" },
    { id: "birds", label: "Birds" },
    { id: "other", label: "Other" }
  ];

  const classTypes = [
    { id: "training", label: "Basic Training" },
    { id: "agility", label: "Agility" },
    { id: "behavior", label: "Behavior" },
    { id: "socialization", label: "Socialization" },
    { id: "first-aid", label: "First Aid" }
  ];

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-md max-h-screen overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Filters</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* Pet Type Filter */}
          <div>
            <Label className="text-base font-medium">Pet Type</Label>
            <div className="space-y-2 mt-3">
              {petTypes.map((petType) => (
                <div key={petType.id} className="flex items-center space-x-2">
                  <Checkbox
                    id={petType.id}
                    checked={localFilters.petTypes?.includes(petType.id) || false}
                    onCheckedChange={(checked) => 
                      handlePetTypeChange(petType.id, checked as boolean)
                    }
                  />
                  <Label htmlFor={petType.id} className="text-sm">
                    {petType.label}
                  </Label>
                </div>
              ))}
            </div>
          </div>
          
          {/* Class Type Filter */}
          <div>
            <Label className="text-base font-medium">Class Type</Label>
            <div className="space-y-2 mt-3">
              {classTypes.map((classType) => (
                <div key={classType.id} className="flex items-center space-x-2">
                  <Checkbox
                    id={classType.id}
                    checked={localFilters.classTypes?.includes(classType.id) || false}
                    onCheckedChange={(checked) => 
                      handleClassTypeChange(classType.id, checked as boolean)
                    }
                  />
                  <Label htmlFor={classType.id} className="text-sm">
                    {classType.label}
                  </Label>
                </div>
              ))}
            </div>
          </div>
          
          {/* Price Range */}
          <div>
            <Label className="text-base font-medium">Price Range</Label>
            <div className="flex items-center space-x-4 mt-3">
              <Input
                type="number"
                placeholder="Min"
                value={localFilters.minPrice || ""}
                onChange={(e) => setLocalFilters({
                  ...localFilters,
                  minPrice: e.target.value ? parseFloat(e.target.value) : undefined
                })}
                className="flex-1"
              />
              <span className="text-gray-500">-</span>
              <Input
                type="number"
                placeholder="Max"
                value={localFilters.maxPrice || ""}
                onChange={(e) => setLocalFilters({
                  ...localFilters,
                  maxPrice: e.target.value ? parseFloat(e.target.value) : undefined
                })}
                className="flex-1"
              />
            </div>
          </div>
          
          {/* Distance */}
          <div>
            <Label className="text-base font-medium">Distance</Label>
            <Select
              value={localFilters.maxDistance?.toString() || ""}
              onValueChange={(value) => setLocalFilters({
                ...localFilters,
                maxDistance: value ? parseFloat(value) : undefined
              })}
            >
              <SelectTrigger className="mt-3">
                <SelectValue placeholder="Select max distance" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1">Within 1 mile</SelectItem>
                <SelectItem value="5">Within 5 miles</SelectItem>
                <SelectItem value="10">Within 10 miles</SelectItem>
                <SelectItem value="25">Within 25 miles</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          {/* Availability */}
          <div>
            <Label className="text-base font-medium">Availability</Label>
            <div className="space-y-2 mt-3">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="available-only"
                  checked={localFilters.availableOnly || false}
                  onCheckedChange={(checked) => setLocalFilters({
                    ...localFilters,
                    availableOnly: checked as boolean
                  })}
                />
                <Label htmlFor="available-only" className="text-sm">
                  Available only
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="include-waitlist"
                  checked={localFilters.includeWaitlist || false}
                  onCheckedChange={(checked) => setLocalFilters({
                    ...localFilters,
                    includeWaitlist: checked as boolean
                  })}
                />
                <Label htmlFor="include-waitlist" className="text-sm">
                  Include waitlist
                </Label>
              </div>
            </div>
          </div>
        </div>
        
        <div className="flex gap-3 pt-6 border-t">
          <Button variant="outline" onClick={handleClearAll} className="flex-1">
            Clear All
          </Button>
          <Button 
            onClick={handleApplyFilters} 
            className="flex-1 bg-primary text-white hover:bg-primary/90"
          >
            Apply Filters
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
