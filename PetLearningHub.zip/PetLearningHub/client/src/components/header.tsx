import { Heart, User, Wifi, WifiOff } from "lucide-react";
import { useOffline } from "@/hooks/use-offline";
import { Button } from "@/components/ui/button";

export function Header() {
  const isOffline = useOffline();

  return (
    <header className="bg-white shadow-sm sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <div className="text-primary text-2xl mr-2">🐾</div>
            <span className="text-xl font-bold text-primary">PawClass</span>
          </div>
          
          {/* Offline Indicator */}
          {isOffline && (
            <div className="bg-warning text-white px-3 py-1 rounded-full text-sm flex items-center">
              <WifiOff className="h-4 w-4 mr-1" />
              Offline Mode
            </div>
          )}
          
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm" className="text-gray-600 hover:text-primary">
              <Heart className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="sm" className="text-gray-600 hover:text-primary">
              <User className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
}
