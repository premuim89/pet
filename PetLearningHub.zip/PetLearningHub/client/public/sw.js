const CACHE_NAME = 'pawclass-v1';
const STATIC_CACHE_NAME = 'pawclass-static-v1';

// Files to cache for offline functionality
const urlsToCache = [
  '/',
  '/src/main.tsx',
  '/src/index.css',
  'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap',
  'https://cdn.tailwindcss.com'
];

// Install event - cache static assets
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(STATIC_CACHE_NAME)
      .then((cache) => cache.addAll(urlsToCache))
      .then(() => self.skipWaiting())
  );
});

// Activate event - clean up old caches
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheName !== CACHE_NAME && cacheName !== STATIC_CACHE_NAME) {
            return caches.delete(cacheName);
          }
        })
      );
    }).then(() => self.clients.claim())
  );
});

// Fetch event - implement cache-first strategy for API calls and network-first for pages
self.addEventListener('fetch', (event) => {
  const { request } = event;
  const url = new URL(request.url);

  // Handle API requests with cache-first strategy
  if (url.pathname.startsWith('/api/')) {
    event.respondWith(
      caches.open(CACHE_NAME).then((cache) => {
        return cache.match(request).then((cachedResponse) => {
          if (cachedResponse) {
            // Return cached response and update cache in background
            fetch(request).then((response) => {
              if (response.ok) {
                cache.put(request, response.clone());
              }
            }).catch(() => {
              // Network failed, cached response is already being returned
            });
            return cachedResponse;
          }

          // No cached response, try network
          return fetch(request).then((response) => {
            if (response.ok) {
              cache.put(request, response.clone());
            }
            return response;
          }).catch(() => {
            // Network failed and no cache available
            if (url.pathname === '/api/classes') {
              return new Response(JSON.stringify([]), {
                status: 200,
                headers: { 'Content-Type': 'application/json' }
              });
            }
            throw new Error('Network unavailable');
          });
        });
      })
    );
  }
  // Handle static assets with cache-first strategy
  else if (
    request.destination === 'script' ||
    request.destination === 'style' ||
    request.destination === 'image' ||
    url.origin === 'https://fonts.googleapis.com' ||
    url.origin === 'https://cdn.tailwindcss.com' ||
    url.origin === 'https://images.unsplash.com'
  ) {
    event.respondWith(
      caches.match(request).then((response) => {
        if (response) {
          return response;
        }
        return fetch(request).then((response) => {
          if (response.ok) {
            const responseClone = response.clone();
            caches.open(STATIC_CACHE_NAME).then((cache) => {
              cache.put(request, responseClone);
            });
          }
          return response;
        });
      })
    );
  }
  // Handle page requests with network-first strategy
  else {
    event.respondWith(
      fetch(request).catch(() => {
        return caches.match('/').then((response) => {
          return response || new Response('Offline - Please check your connection', {
            status: 503,
            headers: { 'Content-Type': 'text/plain' }
          });
        });
      })
    );
  }
});

// Background sync for failed bookings
self.addEventListener('sync', (event) => {
  if (event.tag === 'background-booking') {
    event.waitUntil(
      // Retry failed bookings when connection is restored
      retryFailedBookings()
    );
  }
});

async function retryFailedBookings() {
  try {
    const failedBookings = await getFailedBookings();
    for (const booking of failedBookings) {
      try {
        const response = await fetch('/api/bookings', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(booking)
        });
        if (response.ok) {
          await removeFailedBooking(booking.id);
        }
      } catch (error) {
        console.warn('Failed to retry booking:', error);
      }
    }
  } catch (error) {
    console.warn('Failed to retry bookings:', error);
  }
}

async function getFailedBookings() {
  // Implementation would depend on how you store failed bookings
  return [];
}

async function removeFailedBooking(id) {
  // Implementation would depend on how you store failed bookings
}
